<?php
include("../core/core.php");
// cek apakah tombol daftar sudah diklik atau blum?
// if(isset($_POST['tbh_brg'])){

  // ambil data dari formulir
  // $name = $_POST['name'];
  // $hrg = $_POST['hrg'];
  // $ktg = $_POST['ktg'];
  // $stk = $_POST['stk'];

  // buat query
  $sql = "UPDATE `verifikasi` SET `status` = 'Diterima' WHERE `verifikasi`.`id` = $id ";
  $query = mysqli_query($connect, $sql)or die(mysqli_error($connect));

  // apakah query simpan berhasil?
  // if( $query ) {
    // kalau berhasil alihkan ke halaman index.php dengan status=sukses
    // header('Location: ../admin/page-index2.php#barang?status=sukses');
    // echo "Sukses";
  // } else {
    // kalau gagal alihkan ke halaman indek.php dengan status=gagal
    // header('Location: ../admin/page-index2.php#barang?status=gagal');
    // echo "Gagal";
  // }

// } else {
  // die("Akses dilarang...");
// }

?>
