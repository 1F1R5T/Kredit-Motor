<!DOCTYPE html>
<html>
<head>
	<title>Kredit Motor - Mudah dan Cepat</title>
	<style type="text/css">
		body {
			/* background-image: url('gambar.jpg'); */
			/* background-repeat: repeat; */
			font-family: sans-serif;
		}
	</style>
</head>
<body>
			404
</body>
</html>
