<?php
include("../core/core.php");
// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['cash'])){

  // ambil data dari formulir
  $nm = $_POST['nm'];
  $name = $_POST['name'];
  $st = $_POST['st'];
  $metode = $_POST['metode'];
  $jenis = $_POST['jenis'];
  $waktu = $_POST['waktu'];
  $qty = $_POST['qty'];
  $kode_barang = $_POST['kode_barang'];

  // buat query
  $sql = "INSERT INTO verifikasi VALUES ('', '$nm', '$name', '$st','$metode', '$jenis', '$waktu', '$qty', '$kode_barang')";
  $query = mysqli_query($connect, $sql)or die(mysqli_error($connect));

  // apakah query simpan berhasil?
  if( $query ) {
    header('location: ../user/page-index.php#info');
    // echo "Sukses";
  } else {
    alert("Hello! Maaf! Pesanan kamu tidak dapat diproses!");
    // echo "Gagal";
  }

} else {
  die("Akses dilarang...");
}
 // } if (isset($_POST['cash'])) {
//   // ambil data dari formulir
//   $id = $_POST['id'];
//   $nama_produk = $_POST['np'];
//   $harga = $_POST['hrg'];
//   $kategori = $_POST['ktg'];
//   $stok = $_POST['stk'];
//
//   $sql = "UPDATE `barang` SET `stok` = $stok-1 WHERE `barang`.`id` = $id ";
//   $query = mysqli_query($connect, $sql)or die(mysqli_error($connect));
//
//   // apakah query simpan berhasil?
//   if( $query ) {
//     header('location: ../user/page-index.php#info');
//     // echo "Sukses";
//   } else {
//     alert("Hello! Maaf! Stok barang tidak dapat dirubah!");
//     // echo "Gagal";
//   }
// } else {
//   die("Akses dilarang...");
// }

?>
